# Ax Runner v1.2

App Android que ejecuta módulos tipo AxManager/KernelSU (con `module.prop`, `service.sh`, `webroot/`)
y les da la API de WebUI (`ksu.exec`, iconos de apps…). Pensada para tu módulo **AI-Auto-Mode**.

## Compilar el APK sin Android Studio (≈ 5 min)
1. Crea un repositorio en GitHub y sube **todo el contenido de esta carpeta** (incluida `.github`).
2. Entra en la pestaña **Actions** → **Build APK** → **Run workflow** (se lanza solo al subir).
3. Al terminar (check verde) abre la ejecución y descarga el artefacto **AxRunner-APK** (zip con el `.apk`).
4. Instala el APK en el móvil.

## Compilar con Android Studio
Abre la carpeta, deja que sincronice Gradle y pulsa Build → Build APK(s).

## Usarlo
1. Instala **Shizuku** y arráncalo (Ajustes → Opciones de desarrollador → Depuración inalámbrica, Android 11+).
2. Abre **Ax Runner** → **Permiso Shizuku** → acepta.
3. **Instalar módulo (.zip)** → elige `AI-Auto-Mode-vX.zip`. Se copia a `/data/local/tmp/axr/<id>/` y arranca.
4. **Abrir** muestra la WebUI del módulo.

## Límites conocidos
- Necesita Shizuku (o root). No incluye su propio emparejamiento de depuración inalámbrica.
- Shizuku no arranca solo tras reiniciar el móvil (sin root): hay que volver a iniciarlo y abrir Ax Runner.
- Código escrito sin poder compilarlo ni probarlo en un móvil: puede requerir pequeños ajustes.

## Novedades v1.1
- Logo: el gato samurái (icono de la app y cabecera).
- Inicio estilo AxManager: tarjeta verde con estado (Running), UID, motor, tiempo, PID y versión de Shizuku; contadores de plugins; información del dispositivo.
- Tarjeta verde personalizable: pon una imagen o un video propio (lápiz de la tarjeta, o en Ajustes). El video va en bucle y sin sonido.
- Plugins con su imagen: se usa la `banner` del `module.prop` (o `banner.jpg/png`). También puedes cambiarla por otra desde la tarjeta del plugin (tócala para desplegar).
- Etiquetas de tamaño, WEBUI y ACTION; interruptor para activar/desactivar cada plugin.
- Barra de navegación flotante (Inicio, Plugins, Ajustes), buscador de plugins y animaciones suaves.
- Arreglo: "Detener" ya no se mata a sí mismo al buscar el proceso del módulo.

## Compilar (cambios técnicos)
Ahora usa Jetpack Compose (Kotlin 1.9.24 + Compose Compiler 1.5.14). El workflow de GitHub Actions no cambia.

## Novedades v1.2
- Identidad visual nueva en azul noche y cian, separada del estilo verde de AxManager.
- Selector nativo **Abrir galería** para elegir imágenes y videos, sin solicitar acceso amplio al almacenamiento.
- Se conserva **Explorar archivos** como alternativa.
- Navegación con iconos vectoriales y encabezados de sección con iconografía contextual.
- Transiciones de pestañas y paneles más breves para reducir la sensación de lentitud.
